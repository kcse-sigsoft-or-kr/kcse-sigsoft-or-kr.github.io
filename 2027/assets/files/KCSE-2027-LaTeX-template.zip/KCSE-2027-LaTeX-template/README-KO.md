# KCSE 2027 LaTeX 논문 양식

## 파일

- `kcse2027.cls`: 공통 지면·서체·제목·머리말·2단 본문 규칙
- `kcse-review.tex`: 심사용 예제. 저자 정보를 소스에도 넣지 않는 안전한 시작점
- `kcse-final.tex`: 최종 제출용 예제. 국·영문 저자·소속·이메일·발표자 표시 포함
- `sample-body.tex`: 표·그림·인용·참고문헌 배치 예제

## 컴파일

XeLaTeX 또는 LuaLaTeX를 사용하십시오. pdfLaTeX는 지원하지 않습니다.

```sh
xelatex kcse-review.tex
xelatex kcse-review.tex

xelatex kcse-final.tex
xelatex kcse-final.tex
```

기본 글꼴은 원본 Word 양식과 동일한 `굴림(Gulim)`입니다. 클래스는 macOS용 Microsoft Word에 포함된 `gulim.ttc`, Windows의 `C:/Windows/Fonts/gulim.ttc`, 운영체제에 등록된 `Gulim` 순서로 찾습니다. 굴림은 상용 운영체제·Microsoft Office에 포함되는 글꼴이므로 템플릿 ZIP에는 글꼴 파일을 넣지 않습니다. 굴림이 없으면 컴파일을 위해 `NanumGothic`으로 대체되며 경고가 표시됩니다.

## 심사용과 최종 제출용

- 심사용: `\documentclass[review]{kcse2027}`. 저자 블록, 감사의 글과 PDF 저자 메타데이터를 출력하지 않습니다.
- 최종 제출용: `\documentclass[final]{kcse2027}`. 국·영문 저자 정보와 감사의 글을 출력합니다.
- 심사용은 클래스가 저자 필드를 숨기더라도 저자 정보를 소스에 넣지 않는 편이 안전합니다. 제공된 `kcse-review.tex`에는 저자 필드가 없습니다.

## 지면 규칙

- A4 세로
- 위 30 mm, 아래 20 mm, 왼쪽·오른쪽 10 mm
- 제목·저자·요약은 1단, 본문·참고문헌·선택 부록은 2단
- 국문 제목 16 pt 굵게, 영문 제목 14 pt 굵게
- 장·절 제목 10 pt 굵게, 본문 10 pt, 요약 본문 9 pt
- 단 사이 10 mm
- 장·절 번호는 `1.`, `1.1` 형식
- 표 이름은 표 위, 그림 이름은 그림 아래
- 머리말과 가운데 쪽번호 포함

## 원본 양식의 페이지 수 규정

- 일반논문: 8--10쪽
- 단편논문: 2--4쪽
- 산업체논문: 4--8쪽 또는 발표자료
- 박사학위 논문: 2쪽
- 학부생논문: 4--8쪽 또는 발표자료


## 제출 전 확인

- 심사용 PDF의 본문, 감사의 글, 파일명과 PDF 문서 속성에 식별정보가 없는지 확인
- 모든 대괄호 예시를 교체하거나 삭제
- 그림·표·인용·참고문헌 번호가 서로 대응하는지 확인
- 최종 PDF에서 글꼴, 수식, 표, 그림, 단 넘침과 쪽번호를 확인
